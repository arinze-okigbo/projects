import java.util.Scanner;
public class GradeCalculator{

	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		System.out.print("What is your exam score: "); //Asks for the user's score
		double examScore = input.nextDouble();


		if(examScore>= 90.0)
			System.out.println("Your grade is: A");
		
		else if (examScore>=80.0 && examScore<=89.0)
			System.out.println("Your grade is: B");

		else if (examScore>=70.0 && examScore<=79.0)
			System.out.println("Your grade is: C");

		else if (examScore>=60.0 && examScore<=69.0)
			System.out.println("Your grade is: D");

		else if (examScore<60.0)
			System.out.println("Your grade is: F");

	}
}