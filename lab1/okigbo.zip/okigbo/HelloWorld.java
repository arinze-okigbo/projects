class HelloWorld{

	public static void main(String[] args){

		System.out.println(); 
		System.out.println("Welcome to 115!"); 
		System.out.println();
		System.out.print("We will be learning object "); 
		System.out.print("oriented programming using"); 
		System.out.println("Java in this course."); 
		System.out.println();
		System.out.print("The more you practice, the ");
		System.out.print("more you will enjoy the course!"); 
		System.out.print("Good luck!"); 
		System.out.println();

	}
}